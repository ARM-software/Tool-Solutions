/**
 *  The content of this header can be customized.
 *  Any definitions in this file will be visible to all generated source files.
 *  This file will be never overridden by ASCET code generator.
 */
#ifndef ESDL_USERCFG_H
#define ESDL_USERCFG_H

#define OSENV_SINGLE_THREADED	1
#define ELSENSE_722				1

#endif /* ESDL_USERCFG_H */
