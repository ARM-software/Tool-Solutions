
/**
 * @file        ESDL_Linear_CharTable1_u32s32.c
 *
 * @copyright   ETAS GmbH, Stuttgart, Germany.
 *
 * @warning     The interpolation routines are provided for example only.
 *              It is not permitted to use them in production code or within
 *              ECUs running in any vehicles.
 *              THE ETAS GROUP OF COMPANIES AND THEIR REPRESENTATIVES, AGENTS
 *              AND AFFILIATED COMPANIES SHALL NOT BE LIABLE FOR ANY DAMAGE OR
 *              INJURY CAUSED BY USE OF THIS ROUTINES.
 **/

#include "ESDL_Linear_Interpolation.h"



/**
 * @fn      sint32 ESDL_Linear_CharTable1_getAt_u32s32 (uint16 xVecLen, const volatile uint32 ESDL_LINEAR_PTR_TYPE xDist, const volatile sint32 ESDL_LINEAR_PTR_TYPE zVal, uint32 x)
 *
 * @brief   Linear interpolation and constant extrapolation for
 *          1D characteristic tables
 *
 * @details
 *
 *    ^ z
 *    |
 *  z2|                       *
 *   z|-------------------o          *       *
 *  z1|               *   |
 *    |                   |                           *
 *    | ------*           |
 *    |                   |
 *    |                   |                                   *------
 *    |--------------------------------------------------------------> x
 *                        x
 *                    x1      x2
 *
 *             (z2-z1)
 *    z = z1 + -------*(x-x1)
 *             (x2-x1)
 *
 * @param   xVecLen   *IN*  number of axis points
 * @param   *xDist    *IN*  pointer to distribution of axis points
 * @param   *zVal     *IN*  pointer to distribution of result value
 * @param   x         *IN*  x argument
 *
 * @return  linear interpolated z value at position x
 *
 **/

sint32 ESDL_Linear_CharTable1_getAt_u32s32
(
    uint16 xVecLen,
    const volatile uint32 ESDL_LINEAR_PTR_TYPE xDist,
    const volatile sint32 ESDL_LINEAR_PTR_TYPE zVal,
    uint32 x
)
{
    /* pre-condition 1:
    ** sampling points in xDist array are strong monotony increasing
    ** for all i1, i2 with i1 < i2 applies xDist[i] < xDist[i2]
    */

    /* pre-condition 2:
    ** number of elements in xDist is equal to number of elements in zVal
    ** xDist.lenght == zVal.length
    */

    /* pre-condition 3:
    ** xVecLen <= xDist.lenght
    */

    if ( (x>=xDist[xVecLen-1]) || (xVecLen==1) )
    {
        /* check if input x is greater than last sampling point in characteristic table
        ** or if characteristic table has only one sampling point.
        ** in this case value at last sampling point should be returned.
        ** constant extrapolation.
        */
        return zVal[xVecLen-1];
    }
    else if (x <= xDist[0])
    {
        /* check if input x is smaller than first sampling point
        ** in this case value at first sampling point should be returned.
        ** constant extrapolation.
        */
        return zVal[0];
    }
    else
    {
        const volatile uint32 ESDL_LINEAR_PTR_TYPE pPos;
        uint32 dX, deltaX;
        unsigned int idx;

        /* otherwise search for the interval [pos, pos+1] with: xDist[pos] <= x && x <= xDist[pos+1]
        ** returned value is pointer pPos, which points to x1 in the ASCII picture above.
        **
        ** assertion: (xDist[0] < x) && (x < xDist[xVecLen-1])
        */
        ESDL_Linear_Search_u32 (xDist, xVecLen, x, &pPos);

        /* assertion: pPos >= xDist
        ** assertion: (pPos - xDist) < xVecLen
        ** assertion: (x-*pPos) >= 0
        ** assertion: (x-*pPos) < MAX_SIZE(uint32)
        ** assertion: (*(pPos+1)-*pPos) >= 0
        ** assertion: (*(pPos+1)-*pPos) < MAX_SIZE(uint32)
        */

        dX = *(pPos+1) - *pPos;
        deltaX = x - *pPos;
        /* pointer arithmetic, but type save: idx >= 0 && idx < xVecLen */
        idx = pPos-xDist;
        return ESDL_Linear_Interpolate_u32s32(zVal[idx], zVal[idx+1], deltaX, dX);
    }
}

