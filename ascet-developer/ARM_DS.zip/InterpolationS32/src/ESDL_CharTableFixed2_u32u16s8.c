
/**
 * @file        ESDL_Linear_CharTableFixed2_u32u16s8.c
 *
 * @brief       Linear interpolation and constant extrapolation for 2D
 *              characteristic tables with fixed (equidistant) axes
 *
 * @copyright   ETAS GmbH, Stuttgart, Germany.
 *
 * @warning     The interpolation routines are provided for example only.
 *              It is not permitted to use them in production code or within
 *              ECUs running in any vehicles.
 *              THE ETAS GROUP OF COMPANIES AND THEIR REPRESENTATIVES, AGENTS
 *              AND AFFILIATED COMPANIES SHALL NOT BE LIABLE FOR ANY DAMAGE OR
 *              INJURY CAUSED BY USE OF THIS ROUTINES.
 **/

#include "ESDL_Linear_Interpolation.h"




/**
 *  @fn     sint8 ESDL_Linear_CharTableFixed2_getAt_u32u16s8 ( uint16 xVecLen, uint32 xOffset, uint32 xDistance, uint16 yVecLen, uint16 yOffset, uint16 yDistance, const volatile sint8 ESDL_LINEAR_PTR_TYPE zVal, uint32 x, uint16 y )
 *
 *  @brief  Linear interpolation and constant extrapolation for
 *          2 dimensional characteristic tables
 *
 *  @param  xVecLen   *IN*  number of x-axis points
 *  @param  xOffset   *IN*  the position of first x-axis point
 *  @param  xDistance *IN*  distance between adjacent x-axis points
 *  @param  yVecLen   *IN*  number of y-axis points
 *  @param  yOffset   *IN*  the position of first y-axis point
 *  @param  yDistance *IN*  distance between adjacent y-axis points
 *  @param  *zVal     *IN*  pointer to distribution of result values
 *  @param  x         *IN*  x argument
 *  @param  y         *IN*  y argument
 *
 *  @return linear interpolated value at position x, y
 *
 **/

sint8 ESDL_Linear_CharTableFixed2_getAt_u32u16s8 (
    uint16 xVecLen,
    uint32 xOffset,
    uint32 xDistance,
    uint16 yVecLen,
    uint16 yOffset,
    uint16 yDistance,
    const volatile sint8 ESDL_LINEAR_PTR_TYPE zVal,
    uint32 x,
    uint16 y
)
{
    uint16 idx_X, idx_Y;    /* characteristic tables have never more than 65535 axis points */
    uint16 baseIndex;
    sint8 v00;     /* is the value at vMat[x1,y1] */
    sint8 v01;     /* is the value at vMat[x1,y2] */
    sint8 v10;     /* is the value at vMat[x2,y1] */
    sint8 v11;     /* is the value at vMat[x2,y2] */
    sint8 v0;      /* interpolation value in y-direction on sampling point x1 */
    sint8 v1;      /* interpolation value in y-direction on sampling point x2 */
    uint32 deltaX = 0;
    uint16 deltaY = 0;

    /* pre-condition 1:
    ** xVecLen * yVecLen <= zVal.lenght
    */

    if (x <= xOffset)
    {
        /* liniar interpolation in x direction before the first axis point */
        idx_X=0;
    }
    else if ( (uint32)(x-xOffset) >= (uint32)((xVecLen-1)*xDistance) )
    {
        /* liniar interpolation in x direction after the last axis point */
        idx_X=(uint16)(xVecLen-1);
    }
    else
    {
        /* calculate the index for zVal array in x direction */
        idx_X = (uint16)((x-xOffset)/xDistance);
        deltaX = x - xOffset - (uint32)idx_X*xDistance;
    }

    if (y <= yOffset)
    {
        /* liniar interpolation in y direction before the first axis point */
        idx_Y=0;
    }
    else if ( (uint16)(y-yOffset) >= (uint16)((yVecLen-1)*yDistance) )
    {
        /* liniar interpolation in y direction after the last axis point */
        idx_Y=(uint16)yVecLen-1;
    }
    else
    {
        /* calculate the index for zVal array in y direction */
        idx_Y = (uint16)((y-yOffset)/yDistance);
        deltaY = y - yOffset - (uint16)idx_Y*yDistance;
    }

    /* pre-condition 1:
    **   (0 <= idx_X) && (idx_X <= xVecLen-1)
    */

    /* pre-condition 2:
    **   (0 <= idx_Y) && (idx_Y <= yVecLen-1)
    */

    baseIndex = idx_Y + (yVecLen * idx_X);
    v00 = zVal[baseIndex];  /* base value at [x1,y1] */

    if( (idx_X<(uint16)(xVecLen-1)) && (idx_Y<(uint16)(yVecLen-1)) )
    {
        /* we can access to array zVal without any limitations */
        v01 = zVal[baseIndex+1];             /* zVal[x1,y2] */
        v10 = zVal[baseIndex+yVecLen];       /* zVal[x2,y1] */
        v11 = zVal[baseIndex+yVecLen+1];     /* zVal[x2,y2] */
    }
    else if( (idx_X<(uint16)(xVecLen-1)) && (idx_Y==(uint16)(yVecLen-1)) )
    {
        /* extrapolation into y direction */
        v01 = v00;
        v10 = zVal[baseIndex+yVecLen];
        v11 = v10;
    }
    else if( (idx_X==(uint16)(xVecLen-1)) && (idx_Y<(uint16)(yVecLen-1)) )
    {
        /* extrapolation into x direction */
        v01 = zVal[baseIndex+1];
        v10 = v00;
        v11 = v01;
    }
    else
    {
        /* totally constant extrapolation in all directions*/
        v01 = v00;
        v10 = v00;
        v11 = v00;
    }

    v0 = ESDL_Linear_Interpolate_u16s8(v00, v01, deltaY, yDistance);
    v1 = ESDL_Linear_Interpolate_u16s8(v10, v11, deltaY, yDistance);
    return ESDL_Linear_Interpolate_u32s8(v0, v1, deltaX, xDistance);
}
