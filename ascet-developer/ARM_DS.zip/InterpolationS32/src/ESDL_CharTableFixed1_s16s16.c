
/**
 * @file        ESDL_Linear_CharTableFixed1_s16s16.c
 *
 * @brief       Linear interpolation and constant extrapolation for 1D
 *              characteristic tables with fixed (equidistant) axes
 *
 * @copyright   ETAS GmbH, Stuttgart, Germany.
 *
 * @warning     The interpolation routines are provided for example only.
 *              It is not permitted to use them in production code or within
 *              ECUs running in any vehicles.
 *              THE ETAS GROUP OF COMPANIES AND THEIR REPRESENTATIVES, AGENTS
 *              AND AFFILIATED COMPANIES SHALL NOT BE LIABLE FOR ANY DAMAGE OR
 *              INJURY CAUSED BY USE OF THIS ROUTINES.
 **/

#include "ESDL_Linear_Interpolation.h" 

/**
 * @fn      sint16 ESDL_Linear_CharTableFixed1_getAt_s16s16 ( uint16 xVecLen, sint16 xOffset, uint16 xDistance, const volatile sint16 ESDL_LINEAR_PTR_TYPE zVal, sint16 x )
 *
 * @brief   Linear interpolation and constant extrapolation
 *
 * @details
 *
 * ^ z
 *    |
 *  z2|                       *
 *   z|-------------------o          *       *
 *  z1|               *   |
 *    |                   |                           *
 *    | ------*           |
 *    |                   |
 *    |                   |                                   *------
 *    |--------------------------------------------------------------> x
 *                        x
 *                    x1      x2
 *
 *             (z2-z1)
 *    z = z1 + -------*(x-x1)
 *             (x2-x1)
 *
 *    for all i: x_(i+1) - x_i = xDistance
 *
 *  @param  xVecLen   *IN*  number of axis points
 *  @param  xOffset   *IN*  the position of first axis point
 *  @param  xDistance *IN*  distance between adjacent axis points
 *  @param  *zVal     *IN*  pointer to distribution of result values
 *  @param  x         *IN*  x axis point to calculate value for
 *
 *  @return linear interpolated value at position x
 *
 **/


sint16 ESDL_Linear_CharTableFixed1_getAt_s16s16 (
    uint16 xVecLen,
    sint16 xOffset,
    uint16 xDistance,
    const volatile sint16 ESDL_LINEAR_PTR_TYPE zVal,
    sint16 x
)
{
    /* pre-condition 1:
    ** xVecLen <= zVal.lenght
    */

    /* pre-condition 2:
    ** xDistance > 0
    */

    if (x <= xOffset)
    {
        /* check if input x is smaller than first sampling point
        ** in this case value at first sampling point should be returned.
        ** (constant extrapolation)
        */
        return zVal[0];
    }
    else if ( x>=(xOffset + (sint16)((xVecLen-1)*xDistance) ))
    {
        /* check if input x is greater than last sampling point in characteristic table
        ** or if characteristic table has only one sampling point.
        ** in this case value at last sampling point should be returned.
        ** (constant extrapolation)
        */
        return zVal[xVecLen-1];
    } else {
        /* assertion: 0 <= (int)(x-xOffset)/xDistance <= xVecLen-2
        */
        /* for 16- and 32-bit targets the assumtion is: xVecLen < 65536 */
        uint16 idx = (uint16)((x-xOffset)/xDistance);

        uint16 deltaX = (uint16)(x - xOffset - idx*xDistance);

        return ESDL_Linear_Interpolate_s16s16(zVal[idx], zVal[idx+1], deltaX, xDistance);
    }
}
