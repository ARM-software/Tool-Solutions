
return ((bitArray & bitMask) != 0);
