
return (uint32) ((bitArray >> position) & (uint32) 1);
