	return (bitArray | (((uint32) 1) << position));
