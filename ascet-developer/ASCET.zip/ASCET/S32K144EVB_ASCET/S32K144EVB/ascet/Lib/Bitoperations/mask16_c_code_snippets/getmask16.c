
return (input & mask);
