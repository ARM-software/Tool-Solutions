
/**
 * @file        ESDL_Linear_CharTable2_u8u16s32.c
 *
 * @copyright   ETAS GmbH, Stuttgart, Germany.
 *
 * @warning     The interpolation routines are provided for example only.
 *              It is not permitted to use them in production code or within
 *              ECUs running in any vehicles.
 *              THE ETAS GROUP OF COMPANIES AND THEIR REPRESENTATIVES, AGENTS
 *              AND AFFILIATED COMPANIES SHALL NOT BE LIABLE FOR ANY DAMAGE OR
 *              INJURY CAUSED BY USE OF THIS ROUTINES.
 **/

#include "ESDL_Linear_Interpolation.h"


 
    
 
     

/**
 * @fn      sint32 ESDL_Linear_CharTable2_getAt_u8u16s32 ( uint16 xVecLen, const volatile uint8 ESDL_LINEAR_PTR_TYPE xDist, uint16 yVecLen, const volatile uint16 ESDL_LINEAR_PTR_TYPE yDist, const volatile sint32 ESDL_LINEAR_PTR_TYPE zVal, uint8 x, uint16 y )
 *
 * @brief   Linear interpolation and constant extrapolation for
 *          2D characteristic tables
 *
 * @param   xVecLen  *IN* number of x-axis points
 * @param   *xDist   *IN* pointer to distribution of x-axis points
 * @param   yVecLen  *IN* number of y-axis point
 * @param   *yDist   *IN* pointer to distribution of y-axis points
 * @param   *zVal    *IN* pointer to distribution of result value
 * @param   x        *IN* x argument
 * @param   y        *IN* y argument
 *
 * @returns linear interpolated value at position x, y
 *
 **/

sint32 ESDL_Linear_CharTable2_getAt_u8u16s32 (
    uint16 xVecLen,
    const volatile uint8 ESDL_LINEAR_PTR_TYPE xDist,
    uint16 yVecLen,
    const volatile uint16 ESDL_LINEAR_PTR_TYPE yDist,
    const volatile sint32 ESDL_LINEAR_PTR_TYPE zVal,
    uint8 x,
    uint16 y
)
{
    uint8 searchIndexX;
    uint16 searchIndexY;
    uint8 dx, deltaX;
    uint16 dy, deltaY;

    /* pre-condition 1:
    ** sampling points in xDist array are strong monotony increasing
    ** for all i1, i2 with i1 < i2 applies xDist[i] < xDist[i2]
    */

    /* pre-condition 2:
    ** xVecLen <= xDist.lenght
    */

    /* pre-condition 3:
    ** sampling points in yDist array are strong monotony increasing
    ** for all i1, i2 with i1 < i2 applies yDist[i] < yDist[i2]
    */

    /* pre-condition 2:
    ** yVecLen <= yDist.lenght
    */

    /* Distribution search on x-axis */
    ESDL_Linear_Distr_Search_u8 (xDist, xVecLen, x, &searchIndexX, &deltaX, &dx);

    /* Distribution search on y-axis */
    ESDL_Linear_Distr_Search_u16 (yDist, yVecLen, y, &searchIndexY, &deltaY, &dy);

    return( ESDL_Linear_GroupTable2_getAt_u8u16s32(zVal, searchIndexX, deltaX, dx, xVecLen, searchIndexY, deltaY, dy, yVecLen) );
}
