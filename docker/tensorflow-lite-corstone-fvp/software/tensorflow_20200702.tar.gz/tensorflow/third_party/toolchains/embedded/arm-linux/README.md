# ARM GCC toolchains

This repository contains Bazel C++ toolchain configurations for ARM GCC.
The following toolchains are configured:

source: https://developer.arm.com/tools-and-software/open-source-software/developer-tools/gnu-toolchain/gnu-a/downloads
- gcc 8.3
- glibc 2.28

target cpu: aarch64, armhf
