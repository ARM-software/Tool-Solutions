# Embedded toolchains

This repository contains toolchains for various embedded systems such as
Raspberry Pi and Coral development boards.
